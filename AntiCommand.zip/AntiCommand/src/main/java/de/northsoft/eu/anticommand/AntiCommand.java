package de.northsoft.eu.anticommand;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;

public final class AntiCommand extends JavaPlugin implements Listener {

    @Override
    public void onEnable() {
        // Plugin startup logic
        Config.setDefaults();
        configk.setDefaults();

        getServer().getPluginManager().registerEvents(this, (Plugin) this);

    }
    @EventHandler
    public void onPlayerCommandPreprocess(PlayerCommandPreprocessEvent e) {
        Player p = e.getPlayer();
        if(e.getMessage().toLowerCase().equals("/pl") || e
                .getMessage().toLowerCase().equals("/plugins") || e
                .getMessage().toLowerCase().equals("/version") || e
                .getMessage().toLowerCase().equals("/ver") || e
                .getMessage().toLowerCase().equals("/help") || e
                .getMessage().toLowerCase().equals("/bukkit:?") || e
                .getMessage().toLowerCase().equals("/bukkit:pl") || e
                .getMessage().toLowerCase().equals("/bukkit:plugins") || e
                .getMessage().toLowerCase().equals("/?") || e
                .getMessage().toLowerCase().equals("/icanhasbukkit")){
            if(p.hasPermission(configk.getString("Perms.Name"))) {
                p.sendMessage(Config.getString("Player.perms"));
                return;
            }else {
                p.sendMessage(Config.getString("Player.noperms"));
                e.setCancelled(true);
                return;
            }
        }
    }
}
